dofile(lfs.writedir()..[[Scripts\DCS-BIOS\BIOS.lua]])
